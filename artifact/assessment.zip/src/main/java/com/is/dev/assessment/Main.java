package com.is.dev.assessment;

import com.is.dev.assessment.util.*;
import com.is.dev.assessment.domain.*;

public class Main {

    public static void main(String[] args) {

        // This is the starting point for this assessment

        // Read the README to learn how to begin

        // Before starting, I'd recommend to run the following commands in the root project directory :
        // mvn package
        // java -jar target/dev-assessment-1.0.jar
        // After running the second command it should ouput : "Test successful" from below
        System.out.println("Test successful");
        //this can be deleted once confirmed
    }

}
