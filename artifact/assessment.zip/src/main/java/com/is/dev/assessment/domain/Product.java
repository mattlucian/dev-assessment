package com.is.dev.assessment.domain;


public class Product {



}
