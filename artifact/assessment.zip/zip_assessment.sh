#!/bin/bash

# this command will zip up the assessment into assessment.zip
zip -r assessment.zip zip_assessment.sh products.* pom.xml README.md assumptions.txt run.sh src
